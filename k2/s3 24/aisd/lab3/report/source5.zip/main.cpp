
#include "Student.h"
#include "Sort.h"
#include "Search.h"
#include <iostream>

// Функция для вывода части массива студентов
void print_students_range(Student* students, int start_index, int end_index) {
    for (int i = start_index; i <= end_index; ++i) {
        print_student(students[i]);
    }
}

// Оптимизированный бинарный поиск с использованием индексов
void search_menu(Student* sorted_students, int student_count) {
    char search_choice;
    std::cout << "1. Прямой (последовательный) поиск\n"
                 "2. Бинарный поиск\n"
                 "3. Отмена\n"
                 "Введите ваш выбор: ";
    std::cin >> search_choice;
    std::cin.ignore();

    if (search_choice == '3') return;

    int course_key;
    std::cout << "Введите номер курса для поиска: ";
    std::cin >> course_key;

    int left_index = -1, right_index = -1;

    if (search_choice == '2') {
        // Бинарный поиск для нахождения диапазона
        int left = 0, right = student_count - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (sorted_students[mid].course == course_key) {
                left_index = mid;
                right = mid - 1;
            } else if (sorted_students[mid].course > course_key) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }

        if (left_index != -1) {
            left = left_index;
            right = student_count - 1;
            while (left <= right) {
                int mid = (left + right) / 2;
                if (sorted_students[mid].course == course_key) {
                    right_index = mid;
                    left = mid + 1;
                } else if (sorted_students[mid].course > course_key) {
                    right = mid - 1;
                } else {
                    left = mid + 1;
                }
            }
        }
    } else if (search_choice == '1') {
        // Прямой поиск
        for (int i = 0; i < student_count; ++i) {
            if (sorted_students[i].course == course_key) {
                if (left_index == -1) {
                    left_index = i;
                }
                right_index = i;
            }
        }
    }

    if (left_index != -1 && right_index != -1) {
        // Выводим только студентов, которые находятся в найденном диапазоне
        print_students_range(sorted_students, left_index, right_index);
    } else {
        std::cout << "Студенты на данном курсе не найдены\n";
    }
}

int main() {
    int max_students;
    std::cout << "Введите максимальное количество студентов: ";
    std::cin >> max_students;
    std::cin.ignore();

    Student* students = new Student[max_students];
    int student_count = 0;
    Student* sorted_students = nullptr;

    char command;
    bool running = true;
    while (running) {
        std::cout << "1. Добавить студента\n"
                     "2. Показать студентов\n"
                     "3. Выполнить сортировку\n"
                     "4. Поиск студентов по курсу\n"
                     "5. Выход\n"
                     "Введите ваш выбор: ";
        std::cin >> command;
        std::cin.ignore();

        switch (command) {
            case '1':
                add_student(students, student_count, max_students);
                break;
            case '2':
                print_students(students, student_count);
                break;
            case '3':
                sorted_students = sort_menu(students, student_count);
                if (sorted_students) {
                    print_students(sorted_students, student_count);
                }
                break;
            case '4':
                if (sorted_students != nullptr) {
                    search_menu(sorted_students, student_count);
                } else {
                    std::cout << "Сперва выполните сортировку студентов.\n";
                }
                break;
            case '5':
                running = false;
                break;
            default:
                std::cout << "Неверный ввод, попробуйте снова.\n";
        }
    }

    delete[] students; // Освобождение выделенной памяти
    delete[] sorted_students; // Освобождение памяти для отсортированных студентов
    return 0;
}
