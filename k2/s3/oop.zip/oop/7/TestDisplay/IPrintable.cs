namespace Utils
{
    using System;

    interface IPrintable
	{
		void Print();
	}
}
