#ifndef SORT_H
#define SORT_H

#include "Student.h"

void bubble_sort(const Student* students, int student_count);
void selection_sort(const Student* students, int student_count);
void quick_sort(const Student* students, int student_count);
void heap_sort(const Student* students, int student_count);

#endif
