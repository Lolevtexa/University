public class RaceCar : Car
{
    public List<string> Competitions { get; set; } = new List<string>(); // e.g. "Daytona 500"
    public string Sponsor { get; set; } = ""; // e.g. "Tide"
    public string Team { get; set; } = ""; // e.g. "Hendrick Motorsports"
    public string Driver { get; set; } = ""; // e.g. "Jimmie Johnson"
    public int Wins { get; set; } = 0; // e.g. 83
    public int Losses { get; set; } = 0; // e.g. 0
}
