#include <SFML/Graphics.hpp>
#include <functional>
#include <iostream>
#include <vector>
#include <cmath>
#include <map>
#include <set>
