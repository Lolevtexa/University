public abstract class Car
{
    public string VIN { get; set; } // e.g. "1M8GDM9AXKP042788"
    public string Make { get; set; } // e.g. "Ford"
    public string Model { get; set; } // e.g. "Mustang"
    public int Year { get; set; } // e.g. 1967
    public string Color { get; set; } // e.g. "Red"
    public int NumDoors { get; set; } // e.g. 2
    public int NumWheels { get; set; } // e.g. 4
    public string FuelType { get; set; } // e.g. "Gasoline"
    public int MaxSpeed { get; set; } // e.g. 150
    public int Horsepower { get; set; } // e.g. 300
}
