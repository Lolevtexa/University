
#ifndef SEARCH_H
#define SEARCH_H

#include "Student.h"

// Прямой (последовательный) поиск
int sequential_search(Student* students, int size, const std::string& key);

// Бинарный поиск
int binary_search(Student* students, int size, const std::string& key);

#endif
