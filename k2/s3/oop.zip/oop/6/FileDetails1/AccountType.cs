
enum AccountType 
{ 
    Checking, 
    Deposit 
}

