class Program
{
    static void Main(string[] args)
    {
        SportCar mySportCar = new SportCar("Ferrari", "Red", 300);
        RaceCar myRaceCar = new RaceCar("McLaren", "Orange", 350, 500);

        Console.WriteLine("My sport car is a {0} {1} that can go up to {2} km/h.", mySportCar.Color, mySportCar.Make, mySportCar.TopSpeed);
        Console.WriteLine("My race car is a {0} {1} that can go up to {2} km/h and has {3} horsepower.", myRaceCar.Color, myRaceCar.Make, myRaceCar.TopSpeed, myRaceCar.Horsepower);
    }
}
