
#include "Search.h"
#include <iostream>
#include <string>

// Прямой (последовательный) поиск
int sequential_search(Student* students, int size, const std::string& key) {
    for (int i = 0; i < size; i++) {
        if (students[i].name == key) {
            return i; // Возвращаем индекс найденного элемента
        }
    }
    return -1; // Если элемент не найден
}

// Бинарный поиск (предполагается, что массив отсортирован)
int binary_search(Student* students, int size, const std::string& key) {
    int left = 0;
    int right = size - 1;
    while (left <= right) {
        int middle = (left + right) / 2;
        if (students[middle].name == key) {
            return middle;
        } else if (students[middle].name < key) {
            left = middle + 1;
        } else {
            right = middle - 1;
        }
    }
    return -1; // Если элемент не найден
}
