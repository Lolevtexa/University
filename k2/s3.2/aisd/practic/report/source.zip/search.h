#pragma once
#include <string>

bool rabinKarpSearch(const std::string& text, const std::string& pattern);
