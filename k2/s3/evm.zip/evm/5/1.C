#include <dos.h>
#include <stdio.h>

union REGS t()
{
    union REGS i, o;
    int86(0x8, &i, &o);
    return o;
}

int main() {
    union REGS o = t();
    printf("%02d:%02d:%02d:%02d:%02d:%02d:%02d:%02d\n", o.h.al, o.h.ah, o.h.bl, o.h.bh, o.h.cl, o.h.ch, o.h.dl, o.h.dh);
    printf("%02d:%02d:%02d:%02d:%02d:%02d:%02d:%02d\n", o.x.ax, o.x.bx, o.x.cx, o.x.dx, o.x.si, o.x.di, o.x.cflag, o.x.flags);
    getch();
    return 0;
}

