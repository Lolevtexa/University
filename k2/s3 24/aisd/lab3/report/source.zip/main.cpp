
#include "Student.h"
#include "Sort.h"
#include "Search.h"
#include <iostream>
#include <string>

void search_menu(Student* sorted_students, int student_count) {
    char search_choice;
    std::cout << "1. Прямой (последовательный) поиск\n"
                 "2. Бинарный поиск\n"
                 "3. Вернуться назад\n"
                 "Введите ваш выбор: ";
    std::cin >> search_choice;
    std::cin.ignore();

    if (search_choice == '3') return;

    std::string search_key;
    std::cout << "Введите имя для поиска: ";
    std::getline(std::cin, search_key);

    int result = -1;
    if (search_choice == '1') {
        result = sequential_search(sorted_students, student_count, search_key);
    } else if (search_choice == '2') {
        result = binary_search(sorted_students, student_count, search_key);
    }

    if (result != -1) {
        std::cout << "Студент найден: " << sorted_students[result].name << "\n";
    } else {
        std::cout << "Студент не найден\n";
    }
}

int main() {
    int max_students;
    std::cout << "Введите максимальное количество студентов: ";
    std::cin >> max_students;
    std::cin.ignore();

    Student* students = new Student[max_students];
    int student_count = 0;

    char command;
    bool running = true;
    while (running) {
        std::cout << "1. Добавить студента\n"
                     "2. Показать студентов\n"
                     "3. Сортировка пузырьком\n"
                     "4. Сортировка выбором\n"
                     "5. Быстрая сортировка\n"
                     "6. Пирамидальная сортировка\n"
                     "7. Поиск студента\n"
                     "8. Выход\n"
                     "Введите ваш выбор: ";
        std::cin >> command;
        std::cin.ignore();
        Student* sorted_students = nullptr;

        switch (command) {
            case '1':
                add_student(students, student_count, max_students);
                break;
            case '2':
                print_students(students, student_count);
                break;
            case '3':
                sorted_students = bubble_sort(students, student_count);
                print_students(sorted_students, student_count);
                break;
            case '4':
                sorted_students = selection_sort(students, student_count);
                print_students(sorted_students, student_count);
                break;
            case '5':
                sorted_students = quick_sort(students, student_count);
                print_students(sorted_students, student_count);
                break;
            case '6':
                sorted_students = heap_sort(students, student_count);
                print_students(sorted_students, student_count);
                break;
            case '7':
                if (sorted_students != nullptr) {
                    search_menu(sorted_students, student_count);
                } else {
                    std::cout << "Сперва отсортируйте студентов.\n";
                }
                break;
            case '8':
                running = false;
                break;
            default:
                std::cout << "Неверный ввод, попробуйте снова.\n";
        }
    }

    delete[] students; // Освобождение выделенной памяти
    return 0;
}
