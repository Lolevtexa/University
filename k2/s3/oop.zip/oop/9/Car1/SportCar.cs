public class SportCar : Car
{
    public string LicensePlate { get; set; } = ""; // e.g. "ABC123"
    public string Owner { get; set; } = ""; // e.g. "John Doe"
    public string InsuranceCompany { get; set; } = ""; // e.g. "Geico"
}
